dsh-plugin-pack 整合包（v2 布局）
===============================

生成时间: 2026-11-04T02:35:38.280Z
来源 profile: desktop
来源目录: D:\Temp\dsh-pets\profile
插件数量: 5

包内结构:
  manifest.json            插件清单与配置
  packages/<包名>-<版本>.tgz  每个插件一个 npm tarball
  data/...                 可选，插件数据目录

每个 .tgz 都是标准的 npm 包（package/ 前缀），可以单独取出来用：
  npm i ./packages/<包名>-<版本>.tgz

插件清单:
  - dsh-plugin-pet@2.0.0  93.5 KiB / 依赖 0 个  → packages/dsh-plugin-pet-2.0.0.tgz
  - pet-whale@1.2.7  3.2 MiB / 依赖 0 个  → packages/pet-whale-1.2.7.tgz
  - dsh-agentic-pet@0.4.9  164 KiB / 依赖 0 个  → packages/dsh-agentic-pet-0.4.9.tgz
  - dsh-whale-pet@0.1.0  559 KiB / 依赖 0 个  → packages/dsh-whale-pet-0.1.0.tgz
  - dsh-desktop-pet@0.2.0  92.1 KiB / 依赖 0 个  → packages/dsh-desktop-pet-0.2.0.tgz

导入方式（任选一种）:
  1. dsh 里拖进「插件 → 导入」的框
  2. 命令行:      dsh-plugin-pack import <这个 zip 的路径>
  3. 让 agent 调用: plugin_pack_import({ file: "<路径>" })

整包和单个 .tgz 都能导入：拖 zip 是装整批，拖 tgz 是只装那一个。
导入会先把 package.json 和 cordis.patch.yml 备份到 profile 的 .plugin-backups/ 下，
然后把插件落到 local-plugins/ 并写回 profile 配置。导入完成后重启 dsh 生效。

