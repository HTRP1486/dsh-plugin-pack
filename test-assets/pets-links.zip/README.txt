这是「链接整合包」——里面没有任何插件文件，只有来源地址。

用法：拖进 dsh-plugin-pack 的导入页，或填下面这个地址：
  https://raw.githubusercontent.com/HTRP1486/dsh-plugin-pack/main/test-assets/pets-links.zip

安装时会逐个从来源下载：
  - dsh-plugin-pet  ←  https://github.com/c-ling/dsh-plugin-pet
  - dsh-pet-whale  ←  https://github.com/nzl153/dsh-pet-whale
  - dsh-agentic-pet  ←  dsh-agentic-pet
  - dsh-whale-pet  ←  dsh-whale-pet
  - dsh-desktop-pet  ←  dsh-desktop-pet

好处：文件只有几 KB，装的时候现取，永远是最新版。
代价：需要联网，且上游仓库删了/改名了就装不上。
